document.getElementById("checkBtn").addEventListener("click", () => {
  const name1 = document.getElementById("name1").value.trim();
  const name2 = document.getElementById("name2").value.trim();
  const resultBox = document.getElementById("resultBox");
  const resultText = document.getElementById("resultText");

  if (!name1 || !name2) {
    resultText.textContent = "Vui lòng nhập đầy đủ tên 💬";
    resultBox.classList.remove("hidden");
    return;
  }

  const lovePercent = Math.floor(Math.random() * 101);
  let message = "";

  if (lovePercent > 90) {
    message = `💖 ${name1} và ${name2} yêu nhau ${lovePercent}%! Định mệnh rồi đó! 💍`;
  } else if (lovePercent > 70) {
    message = `💕 ${name1} và ${name2} hợp nhau ${lovePercent}%! Có thể tiến xa lắm đó!`;
  } else if (lovePercent > 40) {
    message = `💞 ${name1} và ${name2} có ${lovePercent}% tình cảm. Cần thêm thời gian nhé!`;
  } else {
    message = `💔 ${name1} và ${name2} chỉ có ${lovePercent}% thôi... Có lẽ nên làm bạn 😢`;
  }

  resultText.textContent = message;
  resultBox.classList.remove("hidden");
});